import requests

# Define API key, endpoint, and other parameters
api_key = '3dc351da1b754c78b36c6697017a78bb'
endpoint = 'https://api.trafikinfo.trafikverket.se/v2/data.json'
data_type = 'RoadCondition'
version = '1.2'
limit = '10'

# Define XML data
xml_data = f'''<REQUEST>
    <LOGIN authenticationkey="{api_key}"/>
    <QUERY objecttype="{data_type}" schemaversion="{version}" limit="{limit}">
        <FILTER></FILTER>
    </QUERY>
</REQUEST>'''

# Set up headers
headers = {
    'Content-Type': 'application/xml',
}

# Send POST request
response = requests.post(endpoint, data=xml_data, headers=headers)

# Check if the request was successful
if response.status_code == 200:
    data = response.json()
    
    # Check if RESPONSE and RESULT exist
    if 'RESPONSE' in data and 'RESULT' in data['RESPONSE']:
        road_conditions = data['RESPONSE']['RESULT']

        # Create a dictionary to hold locations and their conditions
        location_conditions = {}

        # Collect road conditions and their locations
        for result in road_conditions:
            if 'RoadCondition' in result:
                for condition in result['RoadCondition']:
                    location_text = condition.get('LocationText')
                    condition_code = condition.get('ConditionCode')
                    condition_info = condition.get('ConditionInfo')
                    
                    # Store in dictionary
                    if location_text:
                        print(location_text)
                        location_conditions[location_text] = {
                            'ConditionCode': condition_code,
                            'ConditionInfo': condition_info
                        }

        # Ask user for the road number they want to check
        print("\nAnge vägnummer för att få information om vägen:")
        input_loc = input().strip()  # Use strip() to remove extra spaces

        # Find all locations that contain the input road number
        matched_conditions = {loc: cond for loc, cond in location_conditions.items() if input_loc in loc}

        # Check if any locations match the road number
        if matched_conditions:
            for loc, condition_details in matched_conditions.items():
                # Convert the list in ConditionInfo to a comma-separated string
                condition_info_str = ' och '.join(condition_details['ConditionInfo'])

                if condition_details['ConditionCode'] == 1:
                    print(f"\nVägunderlaget för {loc} med tillståndskod {condition_details['ConditionCode']} är {condition_info_str}, och anses acceptabelt för användning!")
                elif condition_details['ConditionCode'] == 2:
                    print(f"\nVägunderlaget för {loc} med tillståndskod {condition_details['ConditionCode']} är {condition_info_str}, och anses oacceptabelt för användning!")
        else:
            print(f"Inga vägplatser hittades för vägnummer {input_loc}.")
    else:
        print("Inga vägförhållanden hittades i svaret.")
else:
    print(f'Error: {response.status_code}')
    print("Response:", response.text)
